count=1;
while [ $count -lt 3 ]; do
	(/root/nd-iotest.sh &) && (ssh jtg-test4 "/root/nd-iotest.sh &")
	sleep 15
	echo ",,,,,,,RESULT # $count,\"=SUM((INDIRECT(ADDRESS(ROW()-1,COLUMN()))),(INDIRECT(ADDRESS(ROW()-2,COLUMN()))))\",\"=SUM((INDIRECT(ADDRESS(ROW()-1,COLUMN()))),(INDIRECT(ADDRESS(ROW()-2,COLUMN()))))\"" >> /mnt/ossn01/result.csv; 
	echo "" >> /mnt/ossn01/result.csv
	let count=$count+1
done
cp -f /mnt/ossn01/result.csv /var/www/html/ndrax/result.csv