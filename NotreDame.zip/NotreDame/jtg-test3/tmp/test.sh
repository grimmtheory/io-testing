for i in {1..50}; do cat /tmp/seed >> /tmp/jtg-test3-500.mb.file; done
